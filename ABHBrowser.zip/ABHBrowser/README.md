# ABH Browser

Simple Android web browser (Kotlin, WebView). Android 10+ (minSdk 29).

## Build (Android Studio)
1. Android Studio (Koala or newer) la **File > Open** -> `ABHBrowser` folder select pannunga.
2. Gradle sync aaganum (internet venum).
3. Phone connect pannitu **Run**, illana **Build > Build APK(s)**.

## Features
- App icon: earth (globe) ulla "ABH"
- Top: URL + search box, reload, bookmark star, downloads
- Bottom: back, forward, home, new page, tabs, menu
- Menu: Bookmarks, History, Downloads, Desktop mode, Theme (Day / Night / Auto), Settings
- Settings: home page, search engine, JavaScript, desktop mode, theme, clear history, clear cookies
