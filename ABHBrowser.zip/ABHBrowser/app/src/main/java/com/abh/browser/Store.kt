package com.abh.browser

import android.content.Context
import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONArray
import org.json.JSONObject

data class Item(val title: String, val url: String, val time: Long, val extra: String = "")

/** Small SharedPreferences-backed store for settings, bookmarks, history, downloads and open tabs. */
class Store(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("abh_prefs", Context.MODE_PRIVATE)

    companion object {
        const val HISTORY = "history"
        const val BOOKMARKS = "bookmarks"
        const val DOWNLOADS = "downloads"
        const val DEFAULT_HOME = "abh://home"
        const val HOME = DEFAULT_HOME

        val ENGINES = arrayOf("Google", "Bing", "DuckDuckGo", "Yahoo")
        private val ENGINE_URLS = arrayOf(
            "https://www.google.com/search?q=",
            "https://www.bing.com/search?q=",
            "https://duckduckgo.com/?q=",
            "https://search.yahoo.com/search?p="
        )

        private val SCHEME_RE = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://")
        private val LOCAL_RE = Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?(/.*)?$")

        /** theme: 0 = auto, 1 = day, 2 = night */
        fun nightMode(theme: Int): Int = when (theme) {
            1 -> AppCompatDelegate.MODE_NIGHT_NO
            2 -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
    }

    // ---------- settings ----------
    var homepage: String
        get() = sp.getString("home", DEFAULT_HOME) ?: DEFAULT_HOME
        set(v) {
            val t = v.trim()
            val fixed = when {
                t.isEmpty() -> DEFAULT_HOME
                SCHEME_RE.containsMatchIn(t) -> t
                else -> "https://$t"
            }
            sp.edit().putString("home", fixed).apply()
        }

    var engine: Int
        get() = sp.getInt("engine", 0).coerceIn(0, ENGINES.size - 1)
        set(v) { sp.edit().putInt("engine", v).apply() }

    var js: Boolean
        get() = sp.getBoolean("js", true)
        set(v) { sp.edit().putBoolean("js", v).apply() }

    var desktop: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) { sp.edit().putBoolean("desktop", v).apply() }

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    // ---------- url / search ----------
    fun resolve(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return homepage
        if (SCHEME_RE.containsMatchIn(t)) return t
        if (LOCAL_RE.matches(t)) return "http://$t"
        if (!t.contains(' ') && t.contains('.')) return "https://$t"
        return ENGINE_URLS[engine] + Uri.encode(t)
    }

    // ---------- lists ----------
    fun list(key: String): MutableList<Item> {
        val out = mutableListOf<Item>()
        try {
            val a = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Item(o.optString("t"), o.optString("u"), o.optLong("m"), o.optString("x")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(key: String, l: List<Item>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("t", it.title).put("u", it.url).put("m", it.time).put("x", it.extra))
        }
        sp.edit().putString(key, a.toString()).apply()
    }

    fun remove(key: String, index: Int) {
        val l = list(key)
        if (index in l.indices) {
            l.removeAt(index)
            save(key, l)
        }
    }

    fun clear(key: String) {
        sp.edit().remove(key).apply()
    }

    fun addHistory(title: String, url: String) {
        val l = list(HISTORY)
        l.removeAll { it.url == url }
        l.add(0, Item(title.ifBlank { url }, url, System.currentTimeMillis()))
        while (l.size > 500) l.removeAt(l.size - 1)
        save(HISTORY, l)
    }

    fun isBookmarked(url: String?): Boolean =
        url != null && list(BOOKMARKS).any { it.url == url }

    /** @return true if the bookmark was added, false if it was removed */
    fun toggleBookmark(title: String, url: String): Boolean {
        val l = list(BOOKMARKS)
        return if (l.removeAll { it.url == url }) {
            save(BOOKMARKS, l)
            false
        } else {
            l.add(0, Item(title.ifBlank { url }, url, System.currentTimeMillis()))
            save(BOOKMARKS, l)
            true
        }
    }

    fun addDownload(name: String, url: String, id: Long) {
        val l = list(DOWNLOADS)
        l.add(0, Item(name, url, System.currentTimeMillis(), id.toString()))
        while (l.size > 200) l.removeAt(l.size - 1)
        save(DOWNLOADS, l)
    }

    // ---------- open tabs (restored after theme change / app restart) ----------
    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", JSONArray(urls).toString()).putInt("cur", current).apply()
    }

    fun loadTabs(): Pair<List<String>, Int> {
        val urls = mutableListOf<String>()
        try {
            val a = JSONArray(sp.getString("tabs", "[]"))
            for (i in 0 until a.length()) urls.add(a.getString(i))
        } catch (_: Exception) {
        }
        return Pair(urls, sp.getInt("cur", 0))
    }
}
