package com.abh.browser

import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var etHome: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        store = Store(this)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        etHome = findViewById(R.id.etHome)
        etHome.setText(store.homepage)

        val sp = findViewById<Spinner>(R.id.spEngine)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Store.ENGINES)
        sp.setSelection(store.engine)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                store.engine = pos
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val swJs = findViewById<MaterialSwitch>(R.id.swJs)
        swJs.isChecked = store.js
        swJs.setOnCheckedChangeListener { _, checked -> store.js = checked }

        val swDesktop = findViewById<MaterialSwitch>(R.id.swDesktop)
        swDesktop.isChecked = store.desktop
        swDesktop.setOnCheckedChangeListener { _, checked -> store.desktop = checked }

        val rg = findViewById<RadioGroup>(R.id.rgTheme)
        rg.check(
            when (store.theme) {
                1 -> R.id.rbDay
                2 -> R.id.rbNight
                else -> R.id.rbAuto
            }
        )
        rg.setOnCheckedChangeListener { _, id ->
            val t = when (id) {
                R.id.rbDay -> 1
                R.id.rbNight -> 2
                else -> 0
            }
            if (t != store.theme) {
                store.theme = t
                AppCompatDelegate.setDefaultNightMode(Store.nightMode(t))
            }
        }

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            store.clear(Store.HISTORY)
            toast("History cleared")
        }
        findViewById<Button>(R.id.btnClearData).setOnClickListener {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast("Cookies & site data cleared")
        }
    }

    override fun onPause() {
        super.onPause()
        store.homepage = etHome.text.toString()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
