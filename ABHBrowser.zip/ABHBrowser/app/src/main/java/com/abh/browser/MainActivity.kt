package com.abh.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.PopupMenu
import org.json.JSONArray
import org.json.JSONObject

class Tab(val web: WebView) {
    var title: String = "New tab"
    var pending: String? = null   // url waiting to be loaded when the tab is first shown
}

class MainActivity : AppCompatActivity() {

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
    }

    private lateinit var store: Store
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var btnStar: ImageButton
    private lateinit var tabCount: TextView
    private lateinit var defaultUA: String

    private val tabs = mutableListOf<Tab>()
    private var cur = -1
    private val current: Tab? get() = tabs.getOrNull(cur)

    private var filePathCb: ValueCallback<Array<Uri>>? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            filePathCb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            )
            filePathCb = null
        }

    private val listLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.getStringExtra("url")?.let { load(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = Store(this)
        defaultUA = WebSettings.getDefaultUserAgent(this)

        urlBox = findViewById(R.id.urlBox)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.webContainer)
        btnStar = findViewById(R.id.btnStar)
        tabCount = findViewById(R.id.tabCount)

        urlBox.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                load(urlBox.text.toString())
                hideKeyboard()
                urlBox.clearFocus()
                true
            } else false
        }

        findViewById<ImageButton>(R.id.btnReload).setOnClickListener { current?.web?.reload() }
        btnStar.setOnClickListener { toggleBookmark() }
        findViewById<ImageButton>(R.id.btnDownload).setOnClickListener { openList(Store.DOWNLOADS) }
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            current?.web?.let { if (it.canGoBack()) it.goBack() }
        }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener {
            current?.web?.let { if (it.canGoForward()) it.goForward() }
        }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { load(store.homepage) }
        findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener {
            newTab(null)
            urlBox.requestFocus()
        }
        findViewById<View>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val t = current
                when {
                    t != null && t.web.canGoBack() -> t.web.goBack()
                    tabs.size > 1 -> closeTab(cur)
                    else -> finish()
                }
            }
        })

        // restore tabs
        val (saved, savedCur) = store.loadTabs()
        val intentUrl = intent?.data?.toString()
        if (saved.isEmpty()) {
            newTab(intentUrl)
        } else {
            saved.forEach { newTab(it, select = false) }
            switchTo(savedCur.coerceIn(0, tabs.size - 1))
            if (intentUrl != null) newTab(intentUrl)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.data?.toString()?.let { newTab(it) }
    }

    override fun onResume() {
        super.onResume()
        tabs.forEach { applySettings(it.web) }
        current?.web?.onResume()
    }

    override fun onPause() {
        super.onPause()
        current?.web?.onPause()
        store.saveTabs(
            tabs.map { savedUrl(it) },
            cur.coerceAtLeast(0)
        )
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        container.removeAllViews()
        tabs.forEach { it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }

    // ---------------- tabs ----------------

    private fun newTab(url: String?, select: Boolean = true): Tab {
        val t = Tab(createWebView())
        tabs.add(t)
        if (select) {
            switchTo(tabs.size - 1)
            openUrl(t.web, url ?: store.homepage)
        } else {
            t.pending = url
        }
        updateCount()
        return t
    }

    private fun switchTo(i: Int) {
        cur = i
        container.removeAllViews()
        val t = tabs[i]
        container.addView(t.web)
        val p = t.pending
        if (p != null) {
            t.pending = null
            openUrl(t.web, p)
        }
        urlBox.setText(shown(p ?: t.web.url))
        val pr = t.web.progress
        progress.progress = pr
        progress.visibility = if (pr in 1..99) View.VISIBLE else View.GONE
        refreshStar()
        updateCount()
    }

    private fun closeTab(i: Int) {
        val t = tabs.removeAt(i)
        container.removeView(t.web)
        t.web.destroy()
        cur = -1
        if (tabs.isEmpty()) newTab(null) else switchTo(minOf(i, tabs.size - 1))
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, t ->
            (if (i == cur) "● " else "    ") + t.title.ifBlank { t.web.url ?: "New tab" }
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(names) { _, which -> switchTo(which) }
            .setPositiveButton("New tab") { _, _ -> newTab(null) }
            .setNeutralButton("Close current") { _, _ -> closeTab(cur) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateCount() {
        tabCount.text = tabs.size.toString()
    }

    // ---------------- webview ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        w.settings.apply {
            domStorageEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        applySettings(w)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val scheme = r.url.scheme ?: return false
                if (scheme == "http" || scheme == "https" || scheme == "about" || scheme == "data") {
                    return false
                }
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, r.url))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                if (v === current?.web) {
                    if (!urlBox.hasFocus()) urlBox.setText(shown(url))
                    refreshStar()
                }
            }

            override fun onPageFinished(v: WebView, url: String?) {
                if (url != null && url.startsWith("http") && !isHomeUrl(url)) {
                    store.addHistory(v.title ?: url, url)
                    // lets long-press on a <video> offer its available qualities
                    v.evaluateJavascript(VideoJs.JS, null)
                }
                if (v === current?.web) refreshStar()
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === current?.web) {
                    progress.progress = p
                    progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(v: WebView, title: String?) {
                tabs.firstOrNull { it.web === v }?.title = title ?: ""
            }

            override fun onShowFileChooser(
                v: WebView,
                cb: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = cb
                return try {
                    fileLauncher.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    filePathCb = null
                    false
                }
            }
        }

        w.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }
        w.addJavascriptInterface(HomeBridge(), "ABH")
        w.addJavascriptInterface(VideoBridge(), "ABHV")
        w.setOnLongClickListener { onWebLongPress(w) }
        return w
    }

    private fun applySettings(w: WebView) {
        w.settings.javaScriptEnabled = store.js
        w.settings.userAgentString = if (store.desktop) DESKTOP_UA else defaultUA
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        if (Build.VERSION.SDK_INT >= 33) {
            w.settings.isAlgorithmicDarkeningAllowed = night
        } else {
            @Suppress("DEPRECATION")
            w.settings.forceDark =
                if (night) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
        }
    }

    private fun load(input: String) {
        val t = current ?: newTab(null)
        openUrl(t.web, input)
    }

    // ---------------- bookmarks ----------------

    private fun refreshStar() {
        val url = current?.web?.url
        btnStar.setImageResource(
            if (store.isBookmarked(url)) R.drawable.ic_star else R.drawable.ic_star_border
        )
    }

    private fun toggleBookmark() {
        val w = current?.web ?: return
        val url = w.url ?: return
        if (isHomeUrl(url)) {
            toast("Start page cannot be bookmarked")
            return
        }
        val added = store.toggleBookmark(w.title ?: url, url)
        refreshStar()
        toast(if (added) "Bookmark added" else "Bookmark removed")
    }

    // ---------------- downloads ----------------

    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = clean(URLUtil.guessFileName(url, cd, mime))
            val page = current?.web?.url?.takeIf { !isHomeUrl(it) }
            val id = enqueue(url, name, ua, mime, page, true)
            store.addDownload(name, url, id)
            toast("Downloading to ABH Browser folder: $name")
        } catch (_: Exception) {
            toast("Download failed")
        }
    }

    private val dm by lazy { getSystemService(DOWNLOAD_SERVICE) as DownloadManager }

    /** Every download is saved inside Downloads/ABH Browser/<relPath>. */
    private fun enqueue(
        url: String,
        relPath: String,
        ua: String?,
        mime: String?,
        referer: String?,
        notifyDone: Boolean
    ): Long {
        val req = DownloadManager.Request(Uri.parse(url))
            .setNotificationVisibility(
                if (notifyDone) DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                else DownloadManager.Request.VISIBILITY_VISIBLE
            )
            .setTitle(relPath.substringAfterLast('/'))
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ABH Browser/$relPath")
        if (!mime.isNullOrBlank()) req.setMimeType(mime)
        req.addRequestHeader("User-Agent", if (ua.isNullOrBlank()) defaultUA else ua)
        CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
        if (!referer.isNullOrBlank()) req.addRequestHeader("Referer", referer)
        return dm.enqueue(req)
    }

    /** Removes characters Android does not allow in file / folder names. */
    private fun clean(s: String): String {
        val t = s.replace(Regex("[\\\\:*?\"<>|]"), "_").trim().trimStart('.')
        return t.ifEmpty { "file" }
    }

    // ---------------- menu ----------------

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)
        popup.menu.findItem(R.id.m_desktop).isChecked = store.desktop
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.m_bookmarks -> openList(Store.BOOKMARKS)
                R.id.m_history -> openList(Store.HISTORY)
                R.id.m_downloads -> openList(Store.DOWNLOADS)
                R.id.m_desktop -> {
                    store.desktop = !store.desktop
                    tabs.forEach { applySettings(it.web) }
                    current?.web?.reload()
                    toast(if (store.desktop) "Desktop mode on" else "Desktop mode off")
                }
                R.id.m_theme -> showThemeDialog()
                R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        popup.show()
    }

    private fun showThemeDialog() {
        val options = arrayOf("Auto (follow system)", "Day", "Night")
        AlertDialog.Builder(this)
            .setTitle("Theme")
            .setSingleChoiceItems(options, store.theme) { d, which ->
                store.theme = which
                d.dismiss()
                AppCompatDelegate.setDefaultNightMode(Store.nightMode(which))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openList(mode: String) {
        listLauncher.launch(Intent(this, ItemsActivity::class.java).putExtra(ItemsActivity.MODE, mode))
    }

    // ---------------- start page ----------------

    private fun isHomeUrl(u: String?) = u != null && u.startsWith(Home.BASE)

    /** What to show in the URL box: nothing for the start page. */
    private fun shown(u: String?): String =
        if (u == null || isHomeUrl(u) || u == Store.HOME) "" else u

    private fun savedUrl(t: Tab): String {
        val u = t.web.url
        return when {
            u != null && isHomeUrl(u) -> Store.HOME
            u != null -> u
            else -> t.pending ?: store.homepage
        }
    }

    private fun openUrl(w: WebView, input: String) {
        val u = store.resolve(input)
        if (u == Store.HOME) {
            w.loadDataWithBaseURL(Home.BASE, Home.HTML, "text/html", "utf-8", Home.BASE)
        } else {
            w.loadUrl(u)
        }
    }

    /** Lets the start page's search box send text to the browser. */
    private inner class HomeBridge {
        @JavascriptInterface
        fun search(q: String) {
            runOnUiThread {
                if (isHomeUrl(current?.web?.url)) load(q)
            }
        }
    }

    // ---------------- long-press: links, folders ----------------

    private fun onWebLongPress(w: WebView): Boolean {
        val hit = w.hitTestResult
        val extra = hit.extra
        val isLink = hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
            hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
        if (isLink && !extra.isNullOrBlank() && extra.startsWith("http")) {
            showLinkMenu(extra)
            return true
        }
        return false   // other long-presses (text select, video) are handled normally
    }

    private fun isFolderUrl(url: String): Boolean {
        val u = Uri.parse(url)
        return u.query == null && (u.path ?: "").endsWith("/")
    }

    private fun showLinkMenu(url: String) {
        val folder = isFolderUrl(url)
        val items = arrayOf(
            "Open in new tab",
            if (folder) "Download folder (all files + sub folders)" else "Download file",
            "Copy link"
        )
        AlertDialog.Builder(this)
            .setTitle(url.take(80))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> newTab(url)
                    1 -> if (folder) downloadFolder(url)
                    else startDownload(url, current?.web?.settings?.userAgentString, null, null)
                    2 -> {
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("url", url))
                        toast("Link copied")
                    }
                }
            }
            .show()
    }

    /**
     * Folder download: reads the web "Index of /..." listing, walks every sub folder and saves
     * everything to Downloads/ABH Browser/<folder name>/<sub folder>/... with the same names.
     */
    private fun downloadFolder(folderUrl: String) {
        val base = if (folderUrl.endsWith("/")) folderUrl else "$folderUrl/"
        val parsed = Uri.parse(base)
        val rootName = clean(Uri.decode(parsed.pathSegments.lastOrNull() ?: parsed.host ?: "folder"))
        val ua = current?.web?.settings?.userAgentString
        toast("Scanning folder…")
        Thread {
            val files = mutableListOf<Pair<String, String>>()
            try {
                crawl(base, rootName, ua, 0, files, HashSet())
            } catch (_: Exception) {
            }
            if (files.isEmpty()) {
                runOnUiThread { toast("No files found. This page is not a folder listing.") }
                return@Thread
            }
            var ok = 0
            for ((url, rel) in files) {
                try {
                    enqueue(url, rel, ua, null, base, false)
                    ok++
                } catch (_: Exception) {
                }
            }
            store.addFolderDownload("📁 $rootName ($ok files)", base, rootName)
            runOnUiThread {
                toast("Downloading $ok files to ABH Browser/$rootName")
            }
        }.start()
    }

    private fun crawl(
        dirUrl: String,
        relDir: String,
        ua: String?,
        depth: Int,
        out: MutableList<Pair<String, String>>,
        seen: MutableSet<String>
    ) {
        if (depth > 8 || out.size >= 2000 || !seen.add(dirUrl)) return
        val html = fetchText(dirUrl, ua) ?: return
        // only real directory index pages are crawled (never normal web pages)
        val listing = Regex("index of|directory listing|parent directory", RegexOption.IGNORE_CASE)
        if (!listing.containsMatchIn(html)) return
        val dirUri = java.net.URI(dirUrl)
        val basePath = dirUri.rawPath ?: return
        val hrefRe = Regex("href\\s*=\\s*[\"']([^\"'#]+)[\"']", RegexOption.IGNORE_CASE)
        for (m in hrefRe.findAll(html)) {
            if (out.size >= 2000) return
            val href = m.groupValues[1].trim()
            if (href.isEmpty() || href.startsWith("?") ||
                href.startsWith("javascript:", true) || href.startsWith("mailto:", true)
            ) continue
            val resolved = try {
                dirUri.resolve(href.replace(" ", "%20").replace("&amp;", "&"))
            } catch (_: Exception) {
                continue
            }
            if (resolved.host != dirUri.host || resolved.rawQuery != null) continue
            val path = resolved.rawPath ?: continue
            if (!path.startsWith(basePath) || path == basePath) continue
            val rel = path.substring(basePath.length)          // "sub/" or "file.txt"
            val name = clean(Uri.decode(rel.trimEnd('/')))
            if (rel.trimEnd('/').contains('/')) continue       // only direct children
            val full = resolved.toString()
            if (path.endsWith("/")) {
                crawl(full, "$relDir/$name", ua, depth + 1, out, seen)
            } else if (seen.add(full)) {
                out.add(Pair(full, "$relDir/$name"))
            }
        }
    }

    private fun fetchText(url: String, ua: String?): String? = try {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", if (ua.isNullOrBlank()) defaultUA else ua)
        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
        if (c.responseCode in 200..299) {
            c.inputStream.bufferedReader().use { r ->
                val sb = StringBuilder()
                val cb = CharArray(8192)
                while (sb.length < 5_000_000) {
                    val n = r.read(cb)
                    if (n <= 0) break
                    sb.append(cb, 0, n)
                }
                sb.toString()
            }
        } else null
    } catch (_: Exception) {
        null
    }

    // ---------------- long-press: video quality ----------------

    private class VideoOpt(val label: String, val url: String)

    private inner class VideoBridge {
        @JavascriptInterface
        fun video(json: String) {
            runOnUiThread { showVideoDialog(json) }
        }
    }

    private fun showVideoDialog(json: String) {
        try {
            val o = JSONObject(json)
            val page = o.optString("page").substringBefore('#')
            val title = o.optString("title")
            val h = o.optInt("h")
            val arr = o.optJSONArray("list") ?: JSONArray()
            val seen = HashSet<String>()
            val opts = mutableListOf<VideoOpt>()
            val qRe = Regex("(?<![0-9])(144|240|360|480|540|720|1080|1440|2160)p?(?![0-9])")
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val u = e.optString("u")
                if (!u.startsWith("http") || u.contains(".m3u8", true) || u.contains(".mpd", true)) continue
                if (!seen.add(u)) continue
                var label = e.optString("l").trim()
                if (label.isEmpty()) label = qRe.find(u)?.groupValues?.get(1)?.let { "${it}p" } ?: ""
                if (label.isEmpty() && arr.length() == 1 && h > 0) label = "${h}p"
                if (label.isEmpty()) label = "Original"
                if (label.all { it.isDigit() }) label += "p"
                opts.add(VideoOpt(label, u))
            }
            opts.sortBy { Regex("\\d+").find(it.label)?.value?.toIntOrNull() ?: 0 }

            if (opts.isEmpty()) {
                val yt = Uri.parse(page).host.orEmpty().let {
                    it.contains("youtube") || it.contains("youtu.be")
                }
                AlertDialog.Builder(this)
                    .setTitle("Can't download this video")
                    .setMessage(
                        if (yt) "Downloading from YouTube isn't supported (YouTube's terms). " +
                            "Use YouTube's own offline download instead."
                        else "This site streams the video in a protected / segmented way, " +
                            "so there is no direct video file to download."
                    )
                    .setPositiveButton("OK", null)
                    .show()
                return
            }

            val done = store.videoQualities(page)
            val names = opts.map { it.label + if (done.contains(it.label)) "   ✓✓" else "" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Download quality")
                .setItems(names) { _, which -> downloadVideo(page, title, opts[which]) }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (_: Exception) {
            toast("Could not read video info")
        }
    }

    private fun downloadVideo(page: String, title: String, opt: VideoOpt) {
        try {
            val ext = Uri.parse(opt.url).lastPathSegment?.substringAfterLast('.', "mp4")
                ?.lowercase().orEmpty()
            val safeExt = if (ext in setOf("mp4", "webm", "mkv", "mov", "3gp", "m4v")) ext else "mp4"
            val name = clean(title.ifBlank { "video" }).take(80) + "_" + opt.label + "." + safeExt
            val id = enqueue(opt.url, name, current?.web?.settings?.userAgentString, null, page, true)
            store.addDownload(name, opt.url, id)
            store.markVideo(page, opt.label)
            toast("Downloading ${opt.label} to ABH Browser folder")
        } catch (_: Exception) {
            toast("Download failed")
        }
    }

    // ---------------- helpers ----------------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBox.windowToken, 0)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
