package com.abh.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.PopupMenu

class Tab(val web: WebView) {
    var title: String = "New tab"
    var pending: String? = null   // url waiting to be loaded when the tab is first shown
}

class MainActivity : AppCompatActivity() {

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
    }

    private lateinit var store: Store
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var btnStar: ImageButton
    private lateinit var tabCount: TextView
    private lateinit var defaultUA: String

    private val tabs = mutableListOf<Tab>()
    private var cur = -1
    private val current: Tab? get() = tabs.getOrNull(cur)

    private var filePathCb: ValueCallback<Array<Uri>>? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            filePathCb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            )
            filePathCb = null
        }

    private val listLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.getStringExtra("url")?.let { load(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = Store(this)
        defaultUA = WebSettings.getDefaultUserAgent(this)

        urlBox = findViewById(R.id.urlBox)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.webContainer)
        btnStar = findViewById(R.id.btnStar)
        tabCount = findViewById(R.id.tabCount)

        urlBox.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                load(urlBox.text.toString())
                hideKeyboard()
                urlBox.clearFocus()
                true
            } else false
        }

        findViewById<ImageButton>(R.id.btnReload).setOnClickListener { current?.web?.reload() }
        btnStar.setOnClickListener { toggleBookmark() }
        findViewById<ImageButton>(R.id.btnDownload).setOnClickListener { openList(Store.DOWNLOADS) }
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            current?.web?.let { if (it.canGoBack()) it.goBack() }
        }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener {
            current?.web?.let { if (it.canGoForward()) it.goForward() }
        }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { load(store.homepage) }
        findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener {
            newTab(null)
            urlBox.requestFocus()
        }
        findViewById<View>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val t = current
                when {
                    t != null && t.web.canGoBack() -> t.web.goBack()
                    tabs.size > 1 -> closeTab(cur)
                    else -> finish()
                }
            }
        })

        // restore tabs
        val (saved, savedCur) = store.loadTabs()
        val intentUrl = intent?.data?.toString()
        if (saved.isEmpty()) {
            newTab(intentUrl)
        } else {
            saved.forEach { newTab(it, select = false) }
            switchTo(savedCur.coerceIn(0, tabs.size - 1))
            if (intentUrl != null) newTab(intentUrl)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.data?.toString()?.let { newTab(it) }
    }

    override fun onResume() {
        super.onResume()
        tabs.forEach { applySettings(it.web) }
        current?.web?.onResume()
    }

    override fun onPause() {
        super.onPause()
        current?.web?.onPause()
        store.saveTabs(
            tabs.map { savedUrl(it) },
            cur.coerceAtLeast(0)
        )
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        container.removeAllViews()
        tabs.forEach { it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }

    // ---------------- tabs ----------------

    private fun newTab(url: String?, select: Boolean = true): Tab {
        val t = Tab(createWebView())
        tabs.add(t)
        if (select) {
            switchTo(tabs.size - 1)
            openUrl(t.web, url ?: store.homepage)
        } else {
            t.pending = url
        }
        updateCount()
        return t
    }

    private fun switchTo(i: Int) {
        cur = i
        container.removeAllViews()
        val t = tabs[i]
        container.addView(t.web)
        val p = t.pending
        if (p != null) {
            t.pending = null
            openUrl(t.web, p)
        }
        urlBox.setText(shown(p ?: t.web.url))
        val pr = t.web.progress
        progress.progress = pr
        progress.visibility = if (pr in 1..99) View.VISIBLE else View.GONE
        refreshStar()
        updateCount()
    }

    private fun closeTab(i: Int) {
        val t = tabs.removeAt(i)
        container.removeView(t.web)
        t.web.destroy()
        cur = -1
        if (tabs.isEmpty()) newTab(null) else switchTo(minOf(i, tabs.size - 1))
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, t ->
            (if (i == cur) "● " else "    ") + t.title.ifBlank { t.web.url ?: "New tab" }
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(names) { _, which -> switchTo(which) }
            .setPositiveButton("New tab") { _, _ -> newTab(null) }
            .setNeutralButton("Close current") { _, _ -> closeTab(cur) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateCount() {
        tabCount.text = tabs.size.toString()
    }

    // ---------------- webview ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        w.settings.apply {
            domStorageEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        applySettings(w)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val scheme = r.url.scheme ?: return false
                if (scheme == "http" || scheme == "https" || scheme == "about" || scheme == "data") {
                    return false
                }
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, r.url))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                if (v === current?.web) {
                    if (!urlBox.hasFocus()) urlBox.setText(shown(url))
                    refreshStar()
                }
            }

            override fun onPageFinished(v: WebView, url: String?) {
                if (url != null && url.startsWith("http") && !isHomeUrl(url)) {
                    store.addHistory(v.title ?: url, url)
                }
                if (v === current?.web) refreshStar()
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === current?.web) {
                    progress.progress = p
                    progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(v: WebView, title: String?) {
                tabs.firstOrNull { it.web === v }?.title = title ?: ""
            }

            override fun onShowFileChooser(
                v: WebView,
                cb: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = cb
                return try {
                    fileLauncher.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    filePathCb = null
                    false
                }
            }
        }

        w.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }
        w.addJavascriptInterface(HomeBridge(), "ABH")
        return w
    }

    private fun applySettings(w: WebView) {
        w.settings.javaScriptEnabled = store.js
        w.settings.userAgentString = if (store.desktop) DESKTOP_UA else defaultUA
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        if (Build.VERSION.SDK_INT >= 33) {
            w.settings.isAlgorithmicDarkeningAllowed = night
        } else {
            @Suppress("DEPRECATION")
            w.settings.forceDark =
                if (night) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
        }
    }

    private fun load(input: String) {
        val t = current ?: newTab(null)
        openUrl(t.web, input)
    }

    // ---------------- bookmarks ----------------

    private fun refreshStar() {
        val url = current?.web?.url
        btnStar.setImageResource(
            if (store.isBookmarked(url)) R.drawable.ic_star else R.drawable.ic_star_border
        )
    }

    private fun toggleBookmark() {
        val w = current?.web ?: return
        val url = w.url ?: return
        if (isHomeUrl(url)) {
            toast("Start page cannot be bookmarked")
            return
        }
        val added = store.toggleBookmark(w.title ?: url, url)
        refreshStar()
        toast(if (added) "Bookmark added" else "Bookmark removed")
    }

    // ---------------- downloads ----------------

    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setTitle(name)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrBlank()) req.setMimeType(mime)
            if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val id = dm.enqueue(req)
            store.addDownload(name, url, id)
            toast("Downloading $name")
        } catch (_: Exception) {
            toast("Download failed")
        }
    }

    // ---------------- menu ----------------

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)
        popup.menu.findItem(R.id.m_desktop).isChecked = store.desktop
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.m_bookmarks -> openList(Store.BOOKMARKS)
                R.id.m_history -> openList(Store.HISTORY)
                R.id.m_downloads -> openList(Store.DOWNLOADS)
                R.id.m_desktop -> {
                    store.desktop = !store.desktop
                    tabs.forEach { applySettings(it.web) }
                    current?.web?.reload()
                    toast(if (store.desktop) "Desktop mode on" else "Desktop mode off")
                }
                R.id.m_theme -> showThemeDialog()
                R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        popup.show()
    }

    private fun showThemeDialog() {
        val options = arrayOf("Auto (follow system)", "Day", "Night")
        AlertDialog.Builder(this)
            .setTitle("Theme")
            .setSingleChoiceItems(options, store.theme) { d, which ->
                store.theme = which
                d.dismiss()
                AppCompatDelegate.setDefaultNightMode(Store.nightMode(which))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openList(mode: String) {
        listLauncher.launch(Intent(this, ItemsActivity::class.java).putExtra(ItemsActivity.MODE, mode))
    }

    // ---------------- start page ----------------

    private fun isHomeUrl(u: String?) = u != null && u.startsWith(Home.BASE)

    /** What to show in the URL box: nothing for the start page. */
    private fun shown(u: String?): String =
        if (u == null || isHomeUrl(u) || u == Store.HOME) "" else u

    private fun savedUrl(t: Tab): String {
        val u = t.web.url
        return when {
            u != null && isHomeUrl(u) -> Store.HOME
            u != null -> u
            else -> t.pending ?: store.homepage
        }
    }

    private fun openUrl(w: WebView, input: String) {
        val u = store.resolve(input)
        if (u == Store.HOME) {
            w.loadDataWithBaseURL(Home.BASE, Home.HTML, "text/html", "utf-8", Home.BASE)
        } else {
            w.loadUrl(u)
        }
    }

    /** Lets the start page's search box send text to the browser. */
    private inner class HomeBridge {
        @JavascriptInterface
        fun search(q: String) {
            runOnUiThread {
                if (isHomeUrl(current?.web?.url)) load(q)
            }
        }
    }

    // ---------------- helpers ----------------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBox.windowToken, 0)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
