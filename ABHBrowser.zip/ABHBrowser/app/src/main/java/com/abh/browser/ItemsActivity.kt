package com.abh.browser

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** One screen used for Bookmarks, History and Downloads pages. */
class ItemsActivity : AppCompatActivity() {

    companion object {
        const val MODE = "mode"
    }

    private lateinit var store: Store
    private lateinit var mode: String
    private lateinit var empty: TextView
    private var items = mutableListOf<Item>()
    private val adapter = ItemAdapter()
    private val dm by lazy { getSystemService(DOWNLOAD_SERVICE) as DownloadManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items)
        store = Store(this)
        mode = intent.getStringExtra(MODE) ?: Store.HISTORY

        findViewById<TextView>(R.id.title).text = when (mode) {
            Store.BOOKMARKS -> "Bookmarks"
            Store.DOWNLOADS -> "Downloads"
            else -> "History"
        }
        empty = findViewById(R.id.empty)
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear all?")
                .setMessage("This removes every entry from this list.")
                .setPositiveButton("Clear") { _, _ ->
                    store.clear(mode)
                    refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        val list = findViewById<ListView>(R.id.list)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onItemClicked(items[pos]) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        items = store.list(mode)
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onItemClicked(item: Item) {
        if (mode == Store.DOWNLOADS) {
            openDownload(item)
        } else {
            setResult(RESULT_OK, Intent().putExtra("url", item.url))
            finish()
        }
    }

    private fun openDownload(item: Item) {
        val id = item.extra.toLongOrNull() ?: return
        val uri = dm.getUriForDownloadedFile(id)
        if (uri == null) {
            Toast.makeText(this, "File not available yet", Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, dm.getMimeTypeForDownloadedFile(id))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun statusOf(id: Long): String {
        var c: Cursor? = null
        return try {
            c = dm.query(DownloadManager.Query().setFilterById(id))
            if (c != null && c.moveToFirst()) {
                when (c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                    DownloadManager.STATUS_FAILED -> "Failed"
                    DownloadManager.STATUS_PAUSED -> "Paused"
                    else -> "Downloading…"
                }
            } else "Removed"
        } catch (_: Exception) {
            ""
        } finally {
            c?.close()
        }
    }

    private inner class ItemAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView
                ?: LayoutInflater.from(parent.context).inflate(R.layout.row_item, parent, false)
            val item = items[position]
            v.findViewById<TextView>(R.id.rowTitle).text = item.title
            v.findViewById<TextView>(R.id.rowSub).text =
                if (mode == Store.DOWNLOADS) {
                    val s = item.extra.toLongOrNull()?.let { statusOf(it) } ?: ""
                    if (s.isEmpty()) item.url else "$s · ${item.url}"
                } else item.url
            v.findViewById<ImageButton>(R.id.rowDelete).setOnClickListener {
                store.remove(mode, position)
                refresh()
            }
            return v
        }
    }
}
