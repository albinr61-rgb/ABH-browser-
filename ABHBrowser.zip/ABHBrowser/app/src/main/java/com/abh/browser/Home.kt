package com.abh.browser

/** Built-in ABH start page (shown instead of a website when a tab is at "home"). */
object Home {
    const val BASE = "https://abh.home/"

    const val HTML = """<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>ABH Browser</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:#fff;color:#5f6368;font-family:Roboto,Arial,sans-serif;
display:flex;flex-direction:column;align-items:center;padding:56px 22px 24px}
svg{width:112px;height:112px}
h1{margin:20px 0 28px;font-size:30px;font-weight:700;color:#666}
form{width:100%;max-width:520px;margin:0}
input{width:100%;height:56px;border:1.5px solid #c8c8c8;border-radius:28px;padding:0 24px;
font-size:19px;outline:none;background:#fff;color:#202124}
input:focus{border-color:#1E88E5}
.ql{width:100%;max-width:520px;margin-top:34px}
.ql p{margin:0 0 14px 4px;font-size:18px;color:#777}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.grid a{display:flex;align-items:center;justify-content:center;height:66px;border-radius:20px;
background:#f1f3f4;color:#555;text-decoration:none;font-size:20px}
.grid a:active{background:#e0e3e6}
</style>
</head>
<body>
<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
<defs>
<radialGradient id="g" cx="40%" cy="35%" r="75%">
<stop offset="0" stop-color="#5BB0FF"/><stop offset="0.6" stop-color="#1E6FD0"/><stop offset="1" stop-color="#0B3A8C"/>
</radialGradient>
<clipPath id="c"><circle cx="60" cy="60" r="56"/></clipPath>
</defs>
<circle cx="60" cy="60" r="56" fill="url(#g)"/>
<g clip-path="url(#c)">
<path fill="#3DAA5C" opacity=".92" d="M26,36 C36,24 54,28 58,40 C60,52 48,58 45,70 C42,80 32,76 29,64 C26,54 22,44 26,36Z"/>
<path fill="#3DAA5C" opacity=".92" d="M70,30 C84,24 100,36 96,50 C93,62 82,64 79,76 C76,88 66,80 68,68 C70,56 62,40 70,30Z"/>
<g fill="none" stroke="#fff" stroke-width="1" opacity=".7">
<ellipse cx="60" cy="60" rx="24" ry="56"/><ellipse cx="60" cy="60" rx="42" ry="56"/>
<line x1="60" y1="4" x2="60" y2="116"/><line x1="4" y1="30" x2="116" y2="30"/>
<line x1="4" y1="60" x2="116" y2="60"/><line x1="4" y1="90" x2="116" y2="90"/>
</g>
</g>
<circle cx="60" cy="60" r="56" fill="none" stroke="#fff" stroke-width="2"/>
<text x="60" y="73" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="40"
font-weight="900" fill="#fff" stroke="#0A2A66" stroke-width="5" paint-order="stroke"
stroke-linejoin="round">ABH</text>
</svg>
<h1>ABH Browser</h1>
<form onsubmit="return go()">
<input id="q" type="text" placeholder="Search or type URL" autocomplete="off" autocapitalize="none" enterkeyhint="go">
</form>
<div class="ql">
<p>Quick links</p>
<div class="grid">
<a href="https://www.google.com">Google</a>
<a href="https://www.youtube.com">YouTube</a>
<a href="https://www.wikipedia.org">Wikipedia</a>
<a href="https://github.com">GitHub</a>
</div>
</div>
<script>
function go(){var v=document.getElementById('q').value;if(window.ABH){ABH.search(v);}return false;}
</script>
</body>
</html>"""
}
