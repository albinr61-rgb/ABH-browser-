package com.abh.browser

/**
 * Injected into every page. A long-press (about 0.65 s) on a <video> reports the video files the
 * page itself exposes (src + <source> tags) to the app, which then shows the quality list.
 */
object VideoJs {
    const val JS = """(function(){
if(window.__abhv)return;window.__abhv=1;
var timer=null,sx=0,sy=0;
function absUrl(u){try{return new URL(u,location.href).href;}catch(e){return '';}}
function collect(v){
 var out=[];
 function add(u,l,h){u=absUrl(u||'');if(!u||u.indexOf('http')!==0)return;out.push({u:u,l:l||'',h:h||0});}
 add(v.currentSrc||v.src,v.getAttribute('label')||'',v.videoHeight||0);
 var s=v.querySelectorAll('source');
 for(var i=0;i<s.length;i++){var e=s[i];
  var l=e.getAttribute('label')||e.getAttribute('title')||e.getAttribute('res')||e.getAttribute('size')||'';
  add(e.src||e.getAttribute('src'),l,0);}
 return out;
}
function findVideo(x,y){
 var els=document.elementsFromPoint?document.elementsFromPoint(x,y):[];
 for(var i=0;i<els.length;i++){var el=els[i];
  if(el.tagName==='VIDEO')return el;
  if(el.closest&&el.closest('a[href]'))return null;
  var c=el.closest?el.closest('video'):null;if(c)return c;}
 return null;
}
function fire(x,y){
 var v=findVideo(x,y);if(!v)return;
 try{ABHV.video(JSON.stringify({page:location.href,title:document.title,h:v.videoHeight||0,list:collect(v)}));}catch(e){}
}
function cancel(){clearTimeout(timer);}
document.addEventListener('touchstart',function(ev){
 if(ev.touches.length!==1)return;
 sx=ev.touches[0].clientX;sy=ev.touches[0].clientY;
 clearTimeout(timer);
 timer=setTimeout(function(){fire(sx,sy);},650);
},{capture:true,passive:true});
document.addEventListener('touchmove',function(ev){
 var t=ev.touches[0];if(Math.abs(t.clientX-sx)>12||Math.abs(t.clientY-sy)>12)cancel();
},{capture:true,passive:true});
document.addEventListener('touchend',cancel,true);
document.addEventListener('touchcancel',cancel,true);
})();"""
}
