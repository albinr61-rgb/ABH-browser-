package com.abh.browser

/**
 * Injected into every frame of every page (including iframe players). A long-press (about 0.65 s)
 * on a <video> reports the video files the page itself exposes (src, <source>, data-* attributes)
 * to the app, which then shows the quality list.
 */
object VideoJs {
    const val JS = """(function(){
if(window.__abhv)return;window.__abhv=1;
var timer=null,sx=0,sy=0,lastFire=0;
var LABELS=['label','title','res','size','data-res','data-quality','data-label','data-size','data-height'];
var SRCS=['src','data-src','data-video','data-url','data-file'];
function absUrl(u){try{return new URL(u,location.href).href;}catch(e){return '';}}
function send(s){
 try{
  if(window.ABHV){
   if(typeof ABHV.postMessage==='function')ABHV.postMessage(s);
   else if(typeof ABHV.video==='function')ABHV.video(s);
  }
 }catch(e){}
}
function firstAttr(el,names){
 for(var i=0;i<names.length;i++){var v=el.getAttribute(names[i]);if(v)return v;}
 return '';
}
function collect(v){
 var out=[];
 function add(u,l,h){u=absUrl(u||'');if(!u||u.indexOf('http')!==0)return;out.push({u:u,l:l||'',h:h||0});}
 add(v.currentSrc||v.src,firstAttr(v,LABELS),v.videoHeight||0);
 for(var j=0;j<SRCS.length;j++){var a=v.getAttribute(SRCS[j]);if(a)add(a,firstAttr(v,LABELS),0);}
 var s=v.querySelectorAll('source');
 for(var i=0;i<s.length;i++){
  var e=s[i];var l=firstAttr(e,LABELS);
  add(e.src||e.getAttribute('src'),l,0);
  var d=e.getAttribute('data-src');if(d)add(d,l,0);
 }
 return out;
}
function findVideo(x,y){
 var els=document.elementsFromPoint?document.elementsFromPoint(x,y):[];
 for(var i=0;i<els.length;i++){
  var el=els[i];
  if(el.tagName==='VIDEO')return el;
  if(el.closest&&el.closest('a[href]'))return null;
  var c=el.closest?el.closest('video'):null;if(c)return c;
 }
 return null;
}
function fire(x,y){
 var now=Date.now();if(now-lastFire<1000)return;
 var v=findVideo(x,y);if(!v)return;
 lastFire=now;
 send(JSON.stringify({page:location.href,title:document.title,h:v.videoHeight||0,list:collect(v)}));
}
function cancel(){clearTimeout(timer);}
document.addEventListener('touchstart',function(ev){
 if(ev.touches.length!==1)return;
 sx=ev.touches[0].clientX;sy=ev.touches[0].clientY;
 clearTimeout(timer);
 timer=setTimeout(function(){fire(sx,sy);},650);
},{capture:true,passive:true});
document.addEventListener('touchmove',function(ev){
 var t=ev.touches[0];if(Math.abs(t.clientX-sx)>12||Math.abs(t.clientY-sy)>12)cancel();
},{capture:true,passive:true});
document.addEventListener('touchend',cancel,true);
document.addEventListener('touchcancel',cancel,true);
document.addEventListener('contextmenu',function(ev){fire(ev.clientX,ev.clientY);},true);
})();"""
}
