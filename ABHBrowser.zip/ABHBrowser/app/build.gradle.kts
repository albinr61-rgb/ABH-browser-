plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abh.browser"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abh.browser"
        minSdk = 29
        targetSdk = 34
        // CI run number keeps increasing, so every new build installs as an update
        val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionCode = run
        versionName = "1.$run"
    }

    // Same key for every build => new APK installs over the old one (no uninstall needed)
    signingConfigs {
        create("abh") {
            storeFile = file("abh.jks")
            storePassword = "abhbrowser"
            keyAlias = "abh"
            keyPassword = "abhbrowser"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("abh")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("abh")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
